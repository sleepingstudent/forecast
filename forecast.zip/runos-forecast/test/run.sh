#!/usr/bin/env bash

python3 -m unittest cstats/cstats.py

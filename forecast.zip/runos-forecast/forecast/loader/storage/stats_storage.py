class StatsStorage(object):
    def to_frame_list(self):
        pass

    def switch_load(self):
        pass

    def load(self):
        pass

    def const_load(self):
        pass

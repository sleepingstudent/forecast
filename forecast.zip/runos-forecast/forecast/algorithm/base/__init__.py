from .algorithm import BaseAlgorithm

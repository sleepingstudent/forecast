from .method import LoadForecastMethod
